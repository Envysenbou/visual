﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            runQuery();

        }
        private void runQuery()
        {
            string column1 = textBox1.Text;
            string column2 = textBox2.Text;
            string column3 = textBox3.Text;


            if (string.IsNullOrWhiteSpace(column1) || string.IsNullOrWhiteSpace(column2) || string.IsNullOrWhiteSpace(column3))
            {
                MessageBox.Show(" Bugdiin bicheerei.");
                return;
            }


            string MySqlConnectionString = "Server=127.0.0.1; Port=3306; Username=root; Password=; Database=visualdb";

            using (MySqlConnection databaseConnection = new MySqlConnection(MySqlConnectionString))
            {
                try
                {
                    databaseConnection.Open();

                    string query = "INSERT INTO db (id1, id2, id3) VALUES (@Column1, @Column2, @Column3)";

                    using (MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection))
                    {
                        commandDatabase.Parameters.AddWithValue("@Column1", column1);
                        commandDatabase.Parameters.AddWithValue("@Column2", column2);
                        commandDatabase.Parameters.AddWithValue("@Column3", column3);

                        commandDatabase.ExecuteNonQuery();
                    }

                    MessageBox.Show("Amjilttai medeelel oruulla.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.ToString());
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
