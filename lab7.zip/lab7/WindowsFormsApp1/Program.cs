﻿using System;
using System.Windows.Forms;

namespace YourRestaurantAppNamespace // Replace with your actual namespace
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create and show your main form (e.g., SummaryForm)
            Application.Run(new SummaryForm());
        }
    }
}
