﻿using System;
using System.Windows.Forms;

public partial class AboutForm : Form
{
    public AboutForm()
    {
        InitializeComponent();
    }

    public void DisplayFoodDetails(string foodName, string description, string imagePath)
    {
        // Хоолны нэр, дэлгэрэнгүй мэдээллийг харуулах
        foodNameTextBox.Text = foodName;
        descriptionTextBox.Text = description;
        pictureBox1.ImageLocation = imagePath;
    }
}
