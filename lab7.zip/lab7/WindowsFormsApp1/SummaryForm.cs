﻿using System;
using System.Windows.Forms;
using System.Data;
using YourRestaurantAppNamespace; // Replace with your actual namespace

public partial class SummaryForm : Form
{
    public SummaryForm()
    {
        InitializeComponent();
    }

    public void UpdateSummaryData(DataGridView dataGridView)
    {
        // Өгөгдлийн сангаас DataGridView-ийн өгөгдлийг авах
        this.dataGridView1.DataSource = dataGridView.DataSource;
    }

    private void searchButton_Click(object sender, EventArgs e)
    {
        // Хайлт хийх
        string searchText = searchTextBox.Text;
        (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"ColumnName LIKE '%{searchText}%'";
    }

    private void showAllButton_Click(object sender, EventArgs e)
    {
        // Бүх өгөгдлийг харуулах
        (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "";
    }
}
