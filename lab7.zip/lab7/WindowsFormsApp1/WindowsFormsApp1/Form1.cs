﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class JuiceBarForm : Form
    {
        private int selectedValue;

        public JuiceBarForm()
        {
            InitializeComponent();
            InitializeRadioButtons();
        }

        private void InitializeRadioButtons()
        {
            radioButton1.CheckedChanged += RadioButton_CheckedChanged;
            radioButton2.CheckedChanged += RadioButton_CheckedChanged;
            radioButton3.CheckedChanged += RadioButton_CheckedChanged;
            radioButton4.CheckedChanged += RadioButton_CheckedChanged;
            radioButton6.CheckedChanged += RadioButton_CheckedChanged;
            radioButton7.CheckedChanged += RadioButton_CheckedChanged;
            radioButton8.CheckedChanged += RadioButton_CheckedChanged;
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            int total = 0;

            if (radioButton1.Checked)
            {
                total += 10;
            }
            if (radioButton2.Checked)
            {
                total += 15;
            }
            if (radioButton3.Checked)
            {
                total += 20;
            }
            if (radioButton4.Checked)
            {
                total += 25;
            }
            if (radioButton6.Checked)
            {
                total += 30;
            }
            if (radioButton7.Checked)
            {
                total += 35;
            }
            if (radioButton8.Checked)
            {
                total += 40;
            }

            selectedValue = total;
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton10.Checked)
            {

                selectedValue = selectedValue / 2;
            }
        }


        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {

                selectedValue = selectedValue / 2;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int total = selectedValue;

            if (total > 150)
            {
                double discount = total * 0.15;
                total -= (int)discount;
                MessageBox.Show("Hungulult 15%");
            }

            MessageBox.Show("Niit une($): " + total.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string information = GetSelectedRadioButtonsInformation();
            MessageBox.Show("Medeeleluud:\n" + information);
        }

        private string GetSelectedRadioButtonsInformation()
        {
            StringBuilder info = new StringBuilder();
            info.AppendLine("hool 1,une 10: " + (radioButton1.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("hool 2,une 15: " + (radioButton2.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("hool 3,une 20: " + (radioButton3.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("hool 4,une 25: " + (radioButton4.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("zuush 1,une 30: " + (radioButton6.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("zuush 2,une 35: " + (radioButton7.Checked ? "Songogosn" : "Songoogui"));
            info.AppendLine("zuush 3,une 40: " + (radioButton8.Checked ? "Songogosn" : "Songoogui"));

            return info.ToString();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
            radioButton10.Checked = false;
            radioButton5.Checked = false;
        }

    }
}
